/* 
 * Copyright (c) 2014 CaiQinghua <caiqinghua@gmail.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#include "spi.h"

#ifdef __cplusplus
extern "C"{
#endif

#define SPI_DR DDRB
void spi_setup(uint8_t mode, int dord, int interrupt, uint8_t clock)
{
  if (clock == SPI_SLAVE) { // if slave, MOSI, SS and SCK is input, MISO is output
    SPI_DR &= ~(1<<SPI_MOSI_PIN | 1<<SPI_SS_PIN | 1<<SPI_SCK_PIN); // input
    SPI_DR |= (1<<SPI_MISO_PIN); // output
  } else {
    SPI_DR |= (1<<SPI_MOSI_PIN) | (1<<SPI_SCK_PIN) | (1<<SPI_SS_PIN); // output
    SPI_DR &= ~(1<<SPI_MISO_PIN); // input
  }
  SPCR = ((interrupt ? 1 : 0)<<SPIE) // interrupt enabled
    | (1<<SPE) // enable SPI
    | (dord<<DORD) // LSB or MSB
    | (((clock != SPI_SLAVE) ? 1 : 0) <<MSTR) // Slave or Master
    | (((mode & 0x02) == 2) << CPOL) // clock timing mode CPOL
    | (((mode & 0x01)) << CPHA) // clock timing mode CPHA
    | (((clock & 0x02) == 2) << SPR1) // cpu clock divisor SPR1
    | ((clock & 0x01) << SPR0); // cpu clock divisor SPR0
  SPSR = (((clock & 0x04) == 4) << SPI2X); // clock divisor SPI2X
}

void SPI_Init(void)
{
    spi_setup(SPI_MODE_0, SPI_MSB, SPI_NO_INTERRUPT, SPI_MSTR_CLK2);
}

void spi_disable()
{
  SPCR = 0;
}

uint8_t spi_send(uint8_t out)
{
  SPDR = out; //send data
  while (!(SPSR & (1<<SPIF)));
  return SPDR; //read received data from buffer
}

//for slave mode
uint8_t spi_receive(uint8_t data)
{
  SPDR = data;
  return SPDR;
}

