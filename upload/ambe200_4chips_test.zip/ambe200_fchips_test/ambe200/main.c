/*
 * ambe200.c
 *
 * Created: 2014/4/12 12:08:49
 *  Author: Administrator
 */ 


#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdarg.h>
#include <util/delay.h>
#include "ambe200.h"

#define USART_BAUDRATE 115200
#define BAUD_PRESCALE ((( F_CPU / ( USART_BAUDRATE * 16UL))) - 1)

#define __UART_INTERRUPT_MODE__ 1
void uart_init(void)
{
    UCSR0B |= (1 << RXEN0 ) | (1 << TXEN0 ); // Turn on the transmission and reception circuitry
    UCSR0C |= (1 << UCSZ00 ) | (1 << UCSZ01 ); // Use 8-bit character sizes
    UBRR0H = (BAUD_PRESCALE >> 8) ; // Load upper 8-bits of the baud rate value into the high byte of the UBRR register
    UBRR0L = BAUD_PRESCALE ; // Load lower 8 -bits of the baud rate value into the low byte of the UBRR register
    
    #if __UART_INTERRUPT_MODE__
    UCSR0B |= (1 << RXCIE0 ); // | (1 << TXEN0 ); // Enable the USART Recieve Complete interrupt (USART_RXC)
    sei(); // Enable the Global Interrupt Enable flag so that interrupts can be processed
    #endif
}

void uart_roll_echo(void)
{
    for (;;) // Loop forever
    {        
        //while (( UCSR0A & (1 << RXC0 )) == 0) {}; // Do nothing until data have been received and is ready to be read from UDR
        //ReceivedByte = UDR0 ; // Fetch the received byte value into the variable "ByteReceived"
        PORTC = 0x00;
        while (( UCSR0A & (1 << UDRE0 )) == 0) {}; // Do nothing until UDR is ready for more data to be written to it
        UDR0 = 'a'; //ReceivedByte ; // Echo back the received byte back to the computer
    }
}


#if 0
unsigned char uart_sending = 0;

unsigned char uart_send_buffer[255];

ISR(USART_TX_vect)
{
    if ('\0' != uart_send_buffer[sended])
    {
        UDR0 = uart_send_buffer[sended++];
    }
    else
    {
        uart_sending = 0;
    }
}

void logMsgInterrupt(const char *s)
{
    if (uart_sending)
    {
        return;
    }
    
    sended = 0;
    strcpy(uart_send_buffer, s);
    if('\0' != s[sended])
    {
        while (( UCSR0A & (1 << UDRE0 )) == 0) {}; // Do nothing until UDR is ready for more data to be written to it
        UDR0 = s[sended++] ; // Echo back the received byte back to the computer
        uart_sending = 1;
    }
}
#endif


#if 0
int _logMsg(const char *fmt, ...)
{
    char printf_buf[1024];
    va_list args;
    int printed;
    
    va_start(args, fmt);
    printed = vsprintf(printf_buf, fmt, args);
    va_end(args);
    
    __logMsg(printf_buf);
    
    return printed;
}
#endif


void logMsg(const char *s)
{
    unsigned char sended = 0;
    //strncpy(uart_send_buffer, s, sizeof(uart_send_buffer));
    while(('\0' != s[sended]))
    {
        while (( UCSR0A & (1 << UDRE0 )) == 0) {}; // Do nothing until UDR is ready for more data to be written to it
        UDR0 = s[sended++] ; // Echo back the received byte back to the computer
    }
}

void usb_send(const unsigned char *s, const unsigned size)
{
    unsigned char sended = 0;
    //strncpy(uart_send_buffer, s, sizeof(uart_send_buffer));
    while(sended < size)
    {
        while (( UCSR0A & (1 << UDRE0 )) == 0) {}; // Do nothing until UDR is ready for more data to be written to it
        UDR0 = s[sended++] ; // Echo back the received byte back to the computer
    }
}

void logWithOneHexNum(const char *s, uint32_t num)
{
    char printf_buf[255];
    snprintf(printf_buf, sizeof(printf_buf), "%s: 0x%x.\r\n", s, num);
    logMsg(printf_buf);
}


void logWithOneNum(const char *s, int num)
{
    char printf_buf[255];
    snprintf(printf_buf, sizeof(printf_buf), "%s: %d.\r\n", s, num);
    logMsg(printf_buf);
}

#define USB_RECEIVE_BUFFER_SIZE 256
char g_com_receive_byte = 0;
unsigned char g_usb_receive_buffer_head = 0;
char g_usb_receive_buffer[USB_RECEIVE_BUFFER_SIZE];
unsigned char g_usb_receive_continue_zero_count = 0;
unsigned char g_usb_receive_continue_none_zero_count = 0;

#define WORK_DATA_SIZE 44
#define WORK_DATA_MID_STATE_SIZE 32
#define WORK_DATA_PART_DATA_SIZE 12
unsigned char g_temp_head = 0;
unsigned char g_zero_count = 0;

#define RX_BUFFER_ROLL(a) ((a) & 0xff)

ISR(USART_RX_vect)
{
    char ReceivedByte ;
    ReceivedByte = UDR0 ; // Fetch the received byte value into the variable "ByteReceived"
    //UDR0 = ReceivedByte; //ReceivedByte ; // Echo back the received byte back to the computer
    g_com_receive_byte = ReceivedByte;
    g_usb_receive_buffer[g_usb_receive_buffer_head++] = ReceivedByte;
	if (g_usb_receive_continue_zero_count == 20)
	{
		g_usb_receive_continue_none_zero_count++;
		if (g_usb_receive_continue_none_zero_count == 12)
		{
			g_usb_receive_continue_zero_count = 0;
			g_temp_head = RX_BUFFER_ROLL(g_usb_receive_buffer_head - 1);
			UCSR0B &= ~(1 << RXCIE0 );
		}
	}
	else
	{
		if (ReceivedByte == 0)
		{
			g_usb_receive_continue_zero_count++;
		}
		else
		{
			g_usb_receive_continue_zero_count = 0;
		}
	}
}

void uart_interrupt_echo(void)
{    
    for (;;) // Loop forever
    {
        // Do nothing - echoing is handled by the ISR instead of in the main loop
    }
}

void send_gold_nonce(void)
{
    unsigned char gold_nonce[4] = {0x00, 0x01, 0x87, 0xa2, 0, 0, 0, 0};
    usb_send(gold_nonce, sizeof(gold_nonce));
	_delay_ms(5);
}



typedef int size_t;
void rev(unsigned char *s, size_t l)
{
    size_t i, j;
    unsigned char t;

    for (i = 0, j = l - 1; i < j; i++, j--) {
        t = s[i];
        s[i] = s[j];
        s[j] = t;
    }
}


bool g_test_mode = 1;	
unsigned char g_is_sended_gold_nonce = 0;
unsigned char work_data[WORK_DATA_SIZE];
uint32_t g_calc_nonce_result[50];
unsigned g_calc_nonce_result_head = 0;
int main(void)
{
    
    uart_init();
    AMBE200_Init();
    //logMsg("AMBE200_Init");
    //logMsg("C:core test\r\nI:increment PLL frequency\r\nD:decrement PLL frequency\r\n\r\n");
	
    while(1)
    {		
        if (g_usb_receive_continue_none_zero_count == 12)
        {
			g_usb_receive_continue_none_zero_count = 0;
            unsigned char head = RX_BUFFER_ROLL(g_temp_head - WORK_DATA_MID_STATE_SIZE - 20 - WORK_DATA_PART_DATA_SIZE + 1);
            UCSR0B |= (1 << RXCIE0 );
			
			
			
            for (unsigned char i = 0; i < WORK_DATA_MID_STATE_SIZE; i++)
            {
                work_data[i] = g_usb_receive_buffer[RX_BUFFER_ROLL(head+i)];
            }
            
            for (unsigned char i = 0; i < WORK_DATA_PART_DATA_SIZE; i++)
            {
                work_data[i+WORK_DATA_MID_STATE_SIZE] = g_usb_receive_buffer[RX_BUFFER_ROLL(head + WORK_DATA_MID_STATE_SIZE + 20 + i)];
            }
			
			//AMBE200_reset();
			unsigned char nonce[4];
			memset(nonce, 0, sizeof(nonce));
			AMBE200_CalculateNonce(work_data, nonce, sizeof(nonce));						
            usb_send(nonce, sizeof(nonce));
            _delay_ms(100);
        }
        
		if (g_test_mode)
		{
			switch(g_com_receive_byte)
			{
				case 'H':
					UCSR0B &= ~(1 << RXCIE0 );
					g_com_receive_byte = 0;
					UCSR0B |= (1 << RXCIE0 );
					logMsg("C:core test\r\nI:increment PLL frequency\r\nD:decrement PLL frequency\r\n\r\n");
					break;
				case 'C':
					g_com_receive_byte = 0;
					ambe200_chip_test_all_chip();
					break;
				case 'I':
					g_com_receive_byte = 0;
					AMBE200_IncPLL();
					break;
				case 'D':
					g_com_receive_byte = 0;
					AMBE200_DecPLL();
					break;
				default:
					g_com_receive_byte = 0;
					break;
			}
		}
    }
}
