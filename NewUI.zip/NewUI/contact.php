  <?php include"header.php";?>

         <section id="page-tree">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-sm-5">
                        <h1>Contact us</h1>
                    </div>
                    <div class="col-md-7 col-sm-7">
                        <ol class="breadcrumb pull-right hidden-xs">
                            <li><a href="index.php"><i class="ion-home"></i> Home</a></li>
                            <li><a>pages</a></li>
                            <li class="active"><a>Contact us</a></li>
                        </ol>
                    </div>
                </div><!--row-->
            </div><!--container-->
        </section><!--page-tree-->
        <div class="divied-60"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h3>Get in touch</h3>
                    <p class="margin-btm40">
                             

<h3>China 中国区</h3> 
Eric（彭） <br>
微信: pzj2870 <br>
QQ: 275067139 <br>
微博: 比特币孺子牛<br>
Email: eric#rockminer.com<br>
<div class="divied-60"></div>
<h3>Oversea 海外</h3> 
Alex<br>
Skype: lzp.alex<br>
Email: sales#rockminer.com<br>
<div class="divied-60"></div>

<h3>Cooperation 合作</h3> 
Rock Xie<br>
Email: rockxie#rockminer.com<br>

 
                    </p>
                 
                </div>
                <div class="col-md-4">
                    <h3>Contact info</h3>
                    <p class="margin-btm20">
                    </p>
                    <ul class="list-unstyled contact-list margin-btm20">
                        <li><i class="ion-home"></i> Xiangshan Road,Songgang,Baoan,Shenzhen,China</li>
                        <li><i class="ion-ios7-email"></i> <strong>Email:</strong> rockxie#rockminer.com</li>
                        <li><i class="ion-ios7-world"></i> <strong>Website:</strong> http://www.rockminer.com</li>
                    </ul>
                    <h3>Social Connect</h3>
                    <ul class="list-unstyled list-inline social">
                        <li><a href="#"><i class="ion-social-facebook-outline" data-toggle="tooltip" data-placement="top" title="" data-original-title="Like On Facebook"></i></a></li>
                        <li><a href="http://twitter.com/rockminerinc"><i class="ion-social-twitter-outline" data-toggle="tooltip" data-placement="top" title="" data-original-title="Follow On twitter"></i></a></li>
                        <li><a href="#"><i class="ion-social-googleplus-outline" data-toggle="tooltip" data-placement="top" title="" data-original-title="Follow On googleplus"></i></a></li>
                        <li><a href="#"><i class="ion-social-pinterest-outline" data-toggle="tooltip" data-placement="top" title="" data-original-title="pinterest"></i></a></li>
                        <li><a href="#"><i class="ion-social-skype-outline" data-toggle="tooltip" data-placement="top" title="" data-original-title="skype"></i></a></li>

                    </ul>
                </div>
            </div>
        </div><!--Contact container end-->
        <div class="divied-60"></div>
        <!--google map-->

        <div id="map-canvas" class="carousel"></div>
        <!--google map end-->

      
       <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=true"></script>
    <script type="text/javascript">
      var myLatlng;
      var map;
      var marker;

      function initialize() {
        myLatlng = new google.maps.LatLng(22.804831, 113.877857);

        var mapOptions = {
          zoom: 13,
          center: myLatlng,
          mapTypeId: google.maps.MapTypeId.ROADMAP,
          scrollwheel: false,
          draggable: false
        };
        map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);

        var contentString = '<p style="line-height: 20px;"><strong>ROCKMINER INC</strong></p><p>Xiangshan Road, Shenzhen City, China</p>';

        var infowindow = new google.maps.InfoWindow({
          content: contentString
        });

        marker = new google.maps.Marker({
          position: myLatlng,
          map: map,
          title: 'Marker'
        });

        google.maps.event.addListener(marker, 'click', function() {
          infowindow.open(map,marker);
        });
      }

      google.maps.event.addDomListener(window, 'load', initialize);
    </script>


  <?php include"footer.php";?>

