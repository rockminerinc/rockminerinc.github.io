 <?php include"header.php";?>

        <!--main flex slider start-->
        <section id="main-slider-bg">
            <div class="slider-overlay">
                <div class="slider-main">
                    <div class="container text-center">
                        <ul class="slides">
                            <li>
                                <h1 class="slider-heading">NEW!ROCKMINER R3</h1>
                                <p class="slider-desc">450~490Ghash/s ASIC bitcoin mining device</p>
                                <a href="http://shop.rockminer.com/goods.php?id=41" class="btn btn-lg btn-white">Purchase Now</a>
                            </li>
                            <li>
                                <h1 class="slider-heading">R-BOX for newbies</h1>
                                <p class="slider-desc">Light,quiet and smart.</p>
                                <a href="http://shop.rockminer.com/goods.php?id=33" class="btn btn-lg btn-white">Learn More</a>
                            </li>
                      
                        </ul>
                    </div> <!-- /container -->
                </div><!--slider main-->
            </div><!--slider overlay-->
        </section>
        <!--main flex slider end-->
    
        <section id="recent-work" class="padding-60">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center margin-btm40">
                        <h1>Our Products</h1>
                     </div>
                    <div class="col-md-12">
             

                        <div id="grid" class="row">

                            <div class="portfolio-item mix seo col-xs-12 col-sm-4">
                                <a href="http://shop.rockminer.com/goods.php?id=41">
                                    <div class="image-sec">
                                        <img class="img-responsive" src="http://rm-img.b0.upaiyun.com/rockminer.com/images/r3.png" alt="R3" width="293px">
                                        <div class="image-overlay">
                                            <p><i class="ion-ios7-plus-empty"></i></p>
                                        </div>
                                    </div> <!--image-->
                                </a>
                            </div> <!--portfolio-item -->

                            <div class="portfolio-item mix html seo col-xs-12 col-sm-4">
                                <a href="http://shop.rockminer.com/goods.php?id=33">
                                    <div class="image-sec">
                                        <img class="img-responsive" src="http://shop.rockminer.com/images/201405/thumb_img/33_thumb_G_1401349667643.jpg" alt="R-box">
                                        <div class="image-overlay">
                                            <p><i class="ion-ios7-plus-empty"></i></p>
                                        </div>
                                    </div> <!--image-->
                                </a>
                            </div> <!--portfolio-item -->

                            <div class="portfolio-item mix wordpress html Design col-xs-12 col-sm-4">
                                <a href="http://shop.rockminer.com/goods.php?id=36">
                                    <div class="image-sec">
                                        <img class="img-responsive" src="http://shop.rockminer.com/images/201406/thumb_img/36_thumb_G_1402526265893.jpg" alt="RK-box">
                                        <div class="image-overlay">
                                            <p><i class="ion-ios7-plus-empty"></i></p>
                                        </div>
                                    </div> <!--image-->
                                </a>
                            </div> <!--portfolio-item -->

                                                                       
                        </div> <!--grid -->
                        <div class="divied-40"></div><!--divide by 40px -->
                      
                    </div><!--col-md-12-->
                </div><!--row-->
            </div><!--container end-->
        </section><!--recent work-->

        <section id="about-colored" class="padding-60">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 margin-btm20 text-center">
                        <h1>About Us</h1>
                        <h2 class="subtitle"><i class="ion-ios7-people-outline"></i></h2>
                    </div>
                    <div class="col-sm-8 col-sm-offset-2 text-center margin-btm20">
                        <p>
ROCKMINER is committed to the miner design, produce, sale and mining operation of bitcoin and other crypto currencies. In early stage, we will purchase the third generation chips of ASICMINER to design and produce miners. In the follow-up stage, we plan to enter related industrial chain of crypto currencies. Rock Xie, the co-founder of ROCKMINER, is one of the earliest Bitcoin investors, well-known novel writer, the board member of ASICMINER, and the General Agent of ASICMINER in Asia-Pacific. In November 2013, the team of ROCKMINER is founded with members who have rich experiences in software and hardware R&D, production and sale.                        </p>
                    </div>
                    <div class="col-sm-12 text-center">
                        <ul class="list-unstyled list-inline social">
                            <li><a href="#"><i class="ion-social-facebook-outline"  data-toggle="tooltip" data-placement="top" title="" data-original-title="Like On Facebook"></i></a></li>
                            <li><a href="https://twitter.com/rockminerinc"><i class="ion-social-twitter-outline"  data-toggle="tooltip" data-placement="top" title="" data-original-title="Follow On twitter"></i></a></li>
                            <li><a href="#"><i class="ion-social-googleplus-outline"  data-toggle="tooltip" data-placement="top" title="" data-original-title="Follow On googleplus"></i></a></li>
                            <li><a href="#"><i class="ion-social-rss-outline"  data-toggle="tooltip" data-placement="top" title="" data-original-title="rss"></i></a></li>
                            <li><a href="#"><i class="ion-social-linkedin-outline"  data-toggle="tooltip" data-placement="top" title="" data-original-title="Follow On linkedin"></i></a></li>
                            <li><a href="#"><i class="ion-social-pinterest-outline"  data-toggle="tooltip" data-placement="top" title="" data-original-title="pinterest"></i></a></li>
                            <li><a href="#"><i class="ion-social-skype-outline"  data-toggle="tooltip" data-placement="top" title="" data-original-title="skype"></i></a></li>
                            <li><a href="#"><i class="ion-social-dribbble-outline"  data-toggle="tooltip" data-placement="top" title="" data-original-title="dribbble"></i></a></li>
                            <li><a href="#"><i class="ion-social-yahoo-outline"  data-toggle="tooltip" data-placement="top" title="" data-original-title="yahoo"></i></a></li>
                            <li><a href="#"><i class="ion-social-vimeo-outline"  data-toggle="tooltip" data-placement="top" title="" data-original-title="vimeo"></i></a></li>
                            <li><a href="https://github.com/rockminerinc"><i class="ion-social-github-outline"  data-toggle="tooltip" data-placement="top" title="" data-original-title="github"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div><!--container-->
        </section><!--about Colored-->
        <section id="latest-news" class="padding-60">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 margin-btm40 text-center">
                        <h1>Latest News</h1>
                        <h2 class="subtitle"><i class="ion-compose"></i></h2>
                    </div>
                    <div class="col-sm-4 col-xs-12 margin-btm20">
                        <a href="#">
                            <div class="image-sec">
                                <img class="img-responsive" src="img/img-6.jpg" alt="Portfolio">
                                <div class="image-overlay">
                                    <p>by author | 7 may | Design</p>
                                </div>
                            </div> <!--image-->                          
                        </a>
                        <div class="blog-desc">
                            <h3><a href="#" class="hover-color">Amazing theme for Multi-Purpose</a></h3>
                            <p>
                                aliqua.adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-4 col-xs-12 margin-btm20">
                        <a href="#">
                            <div class="image-sec">
                                <img class="img-responsive" src="img/img-1.jpg" alt="Portfolio">
                                <div class="image-overlay">
                                    <p>by author | 7 may | Design</p>
                                </div>
                            </div> <!--image-->                          
                        </a>
                        <div class="blog-desc">
                            <h3><a href="#" class="hover-color">Amazing theme for Multi-Purpose</a></h3>
                            <p>
                                aliqua.adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-4 col-xs-12 margin-btm20">
                        <a href="#">
                            <div class="image-sec">
                                <img class="img-responsive" src="img/img-2.jpg" alt="Portfolio">
                                <div class="image-overlay">
                                    <p>by author | 7 may | Design</p>
                                </div>
                            </div> <!--image-->                          
                        </a>
                        <div class="blog-desc">
                            <h3><a href="#" class="hover-color">Amazing theme for Multi-Purpose</a></h3>
                            <p>
                                aliqua.adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.
                            </p>
                        </div>
                    </div>                   
                </div><!--row-->                
            </div><!--container-->
        </section><!--latest news-->

<?php include"footer.php";?>
