 <?php include"header.php";?>




         <section id="page-tree">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-sm-5">
                        <h1>About us</h1>
                    </div>
                    <div class="col-md-7 col-sm-7">
                        <ol class="breadcrumb pull-right hidden-xs">
                            <li><a href="index.php"><i class="ion-home"></i> Home</a></li>
                            <li><a>pages</a></li>
                            <li class="active"><a>about-us</a></li>
                        </ol>
                    </div>
                </div><!--row-->
            </div><!--container-->
        </section><!--page-tree-->
        <div class="divied-60"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="flexslider">
                        <ul class="slides">
                            <li>
                                <img src="img/img-1.jpg" class="img-responsive" alt="">
                            </li>
                            <li>
                                <img src="img/img-4.jpg" class="img-responsive" alt="">
                            </li>
                            <li>
                                <img src="img/img-3.jpg" class="img-responsive" alt="">
                            </li>
                        </ul>
                    </div><!--flex slider-->
                </div>
                <div class="col-md-6">
                    <h3>About Company</h3>
                    <p>
ROCKMINER is committed to the miner design, produce, sale and mining operation of bitcoin and other crypto currencies. In early stage, we will purchase the third generation chips of ASICMINER to design and produce miners. In the follow-up stage, we plan to enter related industrial chain of crypto currencies. Rock Xie, the co-founder of ROCKMINER, is one of the earliest Bitcoin investors, well-known novel writer, the board member of ASICMINER, and the General Agent of ASICMINER in Asia-Pacific. In November 2013, the team of ROCKMINER is founded with members who have rich experiences in software and hardware R&D, production and sale.
                    </p>
             
                </div>
            </div>
 
        </div>
      <?php include"footer.php";?>