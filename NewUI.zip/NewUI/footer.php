
        <section id="footer-defoult" class="padding-60">
            <div class="container">
               
                 <div class="row">
                    <div class="col-md-12 text-center margin-btm20">
                        <a href="index.php"><img src="img/logo-white.png"></a>
                    </div>
                    <div class="col-md-12 text-center">
                        <span>&copy; copyright 2014.All right reserved.</span>
                    </div>
                </div>
            </div><!--container-->
        </section><!--footer default end-->
        <!--scripts-->
        <script src="js/jquery-1.10.2.min.js" type="text/javascript"></script>
        <script src="js/jquery.easing.1.3.min.js" type="text/javascript"></script>
        <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="js/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
        <script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
        <script src="js/jquery.mixitup.min.js" type="text/javascript"></script>
        <script src="js/app.js" type="text/javascript"></script>
    </body>
</html>
